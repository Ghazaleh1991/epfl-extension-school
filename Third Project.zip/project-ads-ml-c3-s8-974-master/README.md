# project-ads-ml-c3-s8-974

# In the house-prices project:
It should be noted that the "house-prices-solution-encoding-test-values.ipynb" file is a pre-processor for generating the encoded test features and will generate the "house-prices-test-features.csv" file which is used by the main "house-prices-solution.ipynb" file.
