# capstone-project-ads-ml-c5-s2-974
There are two **.ipynb** files in the repository. The **main project file** is named as **"Capstone Project.ipynb"**. The file contains necessary project descriptions and results. The other **.ipynb** file named as **"Capstone Operations"** is the notebook which contains all the operations performed in this project. In other words, the results obtained in this file are managed in the form of an article and presented in the "Capstone Project.ipynb".

Datasets are provided as excel files which could be identified by their name. Supplementary figures are also provided in the repository.

Regards

Ghazaleh Eslami
